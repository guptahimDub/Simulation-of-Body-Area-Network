# sensor

TODO:
1. add battery level features
2. add custom threshold for dataset


# sink

TODO:
1. add charge API
2. add data sending function
